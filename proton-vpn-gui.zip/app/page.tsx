"use client"

import { VpnDashboard } from "@/components/vpn-dashboard"

export default function Page() {
  return <VpnDashboard />
}
