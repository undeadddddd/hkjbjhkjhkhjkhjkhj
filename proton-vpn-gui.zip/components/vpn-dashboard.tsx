"use client"

import { useState, useEffect } from "react"
import { Shield, Settings, Globe, ChevronDown, MapPin, TrendingUp, Activity } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { cn } from "@/lib/utils"
import Image from "next/image"

const countries = [
  { name: "Australia", city: "Sydney", flag: "🇦🇺", servers: 21 },
  { name: "United States", city: "New York", flag: "🇺🇸", servers: 142 },
  { name: "United Kingdom", city: "London", flag: "🇬🇧", servers: 78 },
  { name: "Japan", city: "Tokyo", flag: "🇯🇵", servers: 54 },
  { name: "Germany", city: "Berlin", flag: "🇩🇪", servers: 92 },
]

export function VpnDashboard() {
  const [isConnected, setIsConnected] = useState(false)
  const [isConnecting, setIsConnecting] = useState(false)
  const [selectedCountry, setSelectedCountry] = useState(countries[0])
  const [showCountries, setShowCountries] = useState(false)

  useEffect(() => {
    // Force dark mode
    document.documentElement.classList.add("dark")
  }, [])

  const toggleConnection = () => {
    if (isConnecting) return
    setIsConnected(!isConnected)
  }

  return (
    <div className="flex min-h-screen flex-col bg-[#0a0a0a]">
      {/* Header */}
      <header className="flex items-center justify-between border-b border-[#1a1a1a] bg-[#0a0a0a] px-6 py-4">
        <div className="flex items-center gap-3">
          <Image
            src="/logo.jpg"
            alt="Aper VPN Logo"
            width={32}
            height={32}
            className="h-8 w-8 rounded-lg object-cover"
          />
          <h1 className="text-xl font-semibold text-white">
            Aper <span className="text-red-500">VPN</span>
          </h1>
        </div>
        <Button variant="ghost" size="icon" className="text-gray-400 hover:text-white">
          <Settings className="h-5 w-5" />
        </Button>
      </header>

      <div className="flex flex-1">
        {/* Main Content */}
        <main className="flex-1 p-6">
          <div className="mx-auto max-w-2xl">
            {/* Connection Status Card */}
            <Card className="border-[#1a1a1a] bg-[#111111] p-8">
              {/* Status Badge */}
              <div className="mb-6 flex justify-center">
                <div
                  className={cn(
                    "flex items-center gap-2 rounded-full px-4 py-2 text-sm font-medium",
                    isConnecting
                      ? "bg-yellow-500/20 text-yellow-400"
                      : isConnected
                        ? "bg-emerald-500/20 text-emerald-400"
                        : "bg-gray-500/20 text-gray-400",
                  )}
                >
                  <div
                    className={cn(
                      "h-2 w-2 rounded-full",
                      isConnecting ? "bg-yellow-400 animate-pulse" : isConnected ? "bg-emerald-400" : "bg-gray-400",
                    )}
                  />
                  {isConnecting ? "Connecting..." : isConnected ? "Protected" : "Not connected"}
                </div>
              </div>

              {/* Stats */}
              {isConnected && (
                <div className="mb-8 grid grid-cols-3 gap-4 text-center">
                  <div>
                    <div className="text-2xl font-semibold text-white">21</div>
                    <div className="text-sm text-gray-400">Active sessions</div>
                  </div>
                  <div>
                    <div className="text-2xl font-semibold text-white">14</div>
                    <div className="text-sm text-gray-400">Trackers stopped</div>
                  </div>
                  <div>
                    <div className="text-2xl font-semibold text-white">1.5 GB</div>
                    <div className="text-sm text-gray-400">Data saved</div>
                  </div>
                </div>
              )}

              {/* Connection Button */}
              <div className="relative mb-8 flex justify-center">
                <button
                  onClick={toggleConnection}
                  disabled={isConnecting}
                  className={cn(
                    "group relative h-48 w-48 rounded-full transition-all duration-300 active:scale-95",
                    isConnecting
                      ? "bg-gradient-to-br from-black via-yellow-900 to-yellow-600 shadow-lg shadow-yellow-500/50 cursor-wait"
                      : isConnected
                        ? "bg-gradient-to-br from-emerald-500 to-teal-600 shadow-lg shadow-emerald-500/50 hover:shadow-emerald-500/70"
                        : "bg-gradient-to-br from-black via-red-900 to-red-600 shadow-lg shadow-red-500/50 hover:shadow-red-500/70",
                  )}
                >
                  <div className="absolute inset-2 flex items-center justify-center rounded-full bg-[#111111]">
                    <div className="text-center">
                      <Shield className={cn("mx-auto mb-2 h-16 w-16 text-white", isConnecting && "animate-pulse")} />
                      <div className="text-sm font-medium text-white">
                        {isConnecting ? "Connecting..." : isConnected ? "Disconnect" : "Connect"}
                      </div>
                    </div>
                  </div>
                </button>

                {/* Animated Ring */}
                {isConnected && !isConnecting && (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="h-56 w-56 animate-ping rounded-full bg-emerald-500/20" />
                  </div>
                )}
              </div>

              {/* Country Selector */}
              <div className="relative">
                <button
                  onClick={() => setShowCountries(!showCountries)}
                  className="flex w-full items-center justify-between rounded-lg border border-[#1a1a1a] bg-[#0a0a0a] px-4 py-3 text-left transition-colors hover:bg-[#1a1a1a]"
                >
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#1a1a1a] text-2xl">
                      {selectedCountry.flag}
                    </div>
                    <div>
                      <div className="font-medium text-white">{selectedCountry.name}</div>
                      <div className="text-sm text-gray-400">{selectedCountry.city}</div>
                    </div>
                  </div>
                  <ChevronDown
                    className={cn("h-5 w-5 text-gray-400 transition-transform", showCountries && "rotate-180")}
                  />
                </button>

                {/* Country Dropdown */}
                {showCountries && (
                  <div className="absolute top-full z-10 mt-2 w-full rounded-lg border border-[#1a1a1a] bg-[#0a0a0a] p-2 shadow-xl">
                    {countries.map((country) => (
                      <button
                        key={country.name}
                        onClick={() => {
                          setSelectedCountry(country)
                          setShowCountries(false)
                        }}
                        className="flex w-full items-center justify-between rounded-lg px-4 py-3 transition-colors hover:bg-[#1a1a1a]"
                      >
                        <div className="flex items-center gap-3">
                          <div className="text-2xl">{country.flag}</div>
                          <div className="text-left">
                            <div className="font-medium text-white">{country.name}</div>
                            <div className="text-sm text-gray-400">{country.city}</div>
                          </div>
                        </div>
                        <div className="text-sm text-gray-400">{country.servers} servers</div>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </Card>

            {/* Quick Settings */}
            <div className="mt-6 grid grid-cols-3 gap-4">
              <Card className="border-[#1a1a1a] bg-[#111111] p-4 text-center transition-colors hover:bg-[#1a1a1a]">
                <Activity className="mx-auto mb-2 h-6 w-6 text-red-500" />
                <div className="text-sm font-medium text-white">NetShield</div>
              </Card>
              <Card className="border-[#1a1a1a] bg-[#111111] p-4 text-center transition-colors hover:bg-[#1a1a1a]">
                <TrendingUp className="mx-auto mb-2 h-6 w-6 text-red-500" />
                <div className="text-sm font-medium text-white">Kill Switch</div>
              </Card>
              <Card className="border-[#1a1a1a] bg-[#111111] p-4 text-center transition-colors hover:bg-[#1a1a1a]">
                <Globe className="mx-auto mb-2 h-6 w-6 text-red-500" />
                <div className="text-sm font-medium text-white">Split Tunnel</div>
              </Card>
            </div>
          </div>
        </main>

        {/* Sidebar - Server List */}
        <aside className="w-80 border-l border-[#1a1a1a] bg-[#0a0a0a] p-6">
          <h2 className="mb-4 text-lg font-semibold text-white">All Countries</h2>
          <div className="space-y-2">
            {countries.map((country) => (
              <button
                key={country.name}
                onClick={() => setSelectedCountry(country)}
                className={cn(
                  "flex w-full items-center justify-between rounded-lg px-4 py-3 transition-colors",
                  selectedCountry.name === country.name
                    ? "bg-red-600/20 text-white"
                    : "text-gray-400 hover:bg-[#1a1a1a] hover:text-white",
                )}
              >
                <div className="flex items-center gap-3">
                  <div className="text-xl">{country.flag}</div>
                  <div className="text-left">
                    <div className="text-sm font-medium">{country.name}</div>
                  </div>
                </div>
                <div className="text-xs">{country.servers}</div>
              </button>
            ))}
          </div>

          <div className="mt-8 rounded-lg border border-[#1a1a1a] bg-[#111111] p-4">
            <div className="mb-2 text-sm font-medium text-white">Connection Info</div>
            <div className="space-y-2 text-xs text-gray-400">
              <div className="flex justify-between">
                <span>IP Address:</span>
                <span className="text-white">192.168.1.1</span>
              </div>
              <div className="flex justify-between">
                <span>Protocol:</span>
                <span className="text-white">WireGuard</span>
              </div>
              <div className="flex justify-between">
                <span>Load:</span>
                <span className="text-emerald-400">23%</span>
              </div>
            </div>
          </div>
        </aside>
      </div>

      {/* Bottom Navigation */}
      <nav className="flex items-center justify-around border-t border-[#1a1a1a] bg-[#0a0a0a] px-6 py-4">
        <Button variant="ghost" className="flex flex-col gap-1 text-red-500 hover:bg-[#1a1a1a]">
          <Shield className="h-5 w-5" />
          <span className="text-xs">Home</span>
        </Button>
        <Button variant="ghost" className="flex flex-col gap-1 text-gray-400 hover:bg-[#1a1a1a] hover:text-white">
          <Globe className="h-5 w-5" />
          <span className="text-xs">Countries</span>
        </Button>
        <Button variant="ghost" className="flex flex-col gap-1 text-gray-400 hover:bg-[#1a1a1a] hover:text-white">
          <MapPin className="h-5 w-5" />
          <span className="text-xs">Profiles</span>
        </Button>
        <Button variant="ghost" className="flex flex-col gap-1 text-gray-400 hover:bg-[#1a1a1a] hover:text-white">
          <Settings className="h-5 w-5" />
          <span className="text-xs">Settings</span>
        </Button>
      </nav>
    </div>
  )
}
